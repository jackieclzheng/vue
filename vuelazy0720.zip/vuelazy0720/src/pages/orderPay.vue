<template>
  <div>
    orderPay
  </div>
</template>
<script>
  export default{
    name:'order-pay'
  }
</script>