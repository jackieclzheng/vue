<template>
  <div>
    alipay
  </div>
</template>
<script>
  export default{
    name:'alipay'
  }
</script>