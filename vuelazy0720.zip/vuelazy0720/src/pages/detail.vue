<template>
  <div>
    detail
  </div>
</template>
<script>
  export default{
    name:'detail'
  }
</script>