<template>
  <div>
    product
  </div>
</template>
<script>
  export default{
    name:'product'
  }
</script>