<template>
  <div>
    orderConfirm
  </div>
</template>
<script>
  export default{
    name:'order-confirm'
  }
</script>