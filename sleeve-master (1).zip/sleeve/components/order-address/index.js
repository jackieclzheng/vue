// components/order-address/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    address:Object,
    status:Number
  },

  /**
   * 组件的初始数据
   */
  data: {
    // _status:nu
  },
  attached() {
    // console.log(this.properties.status)
  },

  observers:{
    // 'status':function (status) {
    //     console.log(status)
    // }
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
